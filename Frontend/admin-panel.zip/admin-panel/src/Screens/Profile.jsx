function Profile() {
  return <>Profile</>;
}

export default Profile;
