function Ticket()
{
    return (
        <div>
            <h1>Login</h1>
        </div>
    )
}
export default Ticket